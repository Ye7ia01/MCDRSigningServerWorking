﻿using iText.Bouncycastle.X509;
using iText.Commons.Bouncycastle.Asn1;
using iText.Commons.Bouncycastle.Asn1.X500;
using iText.Commons.Bouncycastle.Cert;
using iText.Commons.Bouncycastle.Crypto;
using iText.Commons.Bouncycastle.Math;
using iText.Kernel.Geom;
using iText.Kernel.Pdf;
using iText.Signatures;
using Microsoft.AspNetCore.Mvc;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.X509;
using System.Collections;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using XSystem.Security.Cryptography;
using static iText.Signatures.PdfSigner;
using ITSAClient = iText.Signatures.ITSAClient;
//using iTextSharp.text.pdf.security.PdfPKCS7;
using SHA256 = XSystem.Security.Cryptography.SHA256;
using X509Certificate = Org.BouncyCastle.X509.X509Certificate;

namespace MCDRDigitalSignatureClient.Controllers
{


    [ApiController]
    [Route("[controller]")]
    public class PDFPrepareController : ControllerBase
    {

        byte[] hashBeforeAuthAtr;

    
        [HttpGet(Name = "preparePDF")]
        public void testPrepare()
        {
            string src = "C:\\Users\\40338\\Desktop\\Doc1.pdf";
            string dest = "C:\\Users\\40338\\Desktop\\Doc1_signAgilityTest.pdf";
            string final = "C:\\Users\\40338\\Desktop\\Doc1_signAgilityFinal.pdf";
            System.Security.Cryptography.X509Certificates.X509Certificate2Collection certificates;
            System.Security.Cryptography.X509Certificates.X509Store my = new System.Security.Cryptography.X509Certificates.X509Store(System.Security.Cryptography.X509Certificates.StoreName.My, System.Security.Cryptography.X509Certificates.StoreLocation.CurrentUser);
            my.Open(System.Security.Cryptography.X509Certificates.OpenFlags.ReadOnly);

            certificates = my.Certificates.Find(System.Security.Cryptography.X509Certificates.X509FindType.FindBySerialNumber, "5838a8780bc905193f47c12b1aebeba4", false);
            if (certificates.Count == 0) throw new Exception("No certificates found.");

            System.Security.Cryptography.X509Certificates.X509Certificate2 cert = certificates[0];

            System.Security.Cryptography.X509Certificates.X509Chain chain = new System.Security.Cryptography.X509Certificates.X509Chain();
            //chain.Build(cert);

            X509Certificate bouncyCert = DotNetUtilities.FromX509Certificate(cert);

            X509Certificate[] certChain = new X509Certificate[1];
            certChain[0] = bouncyCert;





            byte[] hash = preparePdfDoc(src, dest, "field", certChain);

            byte[] signedHash = signHash(hash, "5838a8780bc905193f47c12b1aebeba4");

            embedSignaturePdf(dest, final, certChain, this.hashBeforeAuthAtr, signedHash);
        }

        [HttpPost(Name = "signHash")]
        public byte[] signHash(byte[] hash, string certSerial)
        {
            //byte[] data = Convert.FromBase64String(hash);
            X509Store store = new X509Store(StoreName.My, StoreLocation.CurrentUser);
            store.Open(OpenFlags.MaxAllowed);

            var foundCerts = store.Certificates.Find(X509FindType.FindBySerialNumber, certSerial, false);
            if (foundCerts.Count == 0)
            {
                return null;
            }

            X509Certificate2 cert = foundCerts[0];

            var privKy = cert.GetRSAPrivateKey();

            byte[] signedData = privKy.SignData(hash, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);

            var pubky = cert.GetRSAPublicKey();

            bool validSignature = pubky.VerifyData(hash, signedData, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);

            return signedData;
        }




        // Backend Module
        [HttpPut(Name = "preparePDF")]
        public byte[] preparePdfDoc(String src, String dest, String fieldname, X509Certificate[] chain)
        {
            PdfReader reader = new PdfReader(src);
            PdfSigner signer = new PdfSigner(reader, new FileStream(dest, FileMode.Create), new StampingProperties());

            PdfSignatureAppearance appearance = signer.GetSignatureAppearance();
            appearance
                .SetPageRect(new Rectangle(36, 748, 200, 100))
                .SetPageNumber(1)
                .SetCertificate(new iText.Bouncycastle.X509.X509CertificateBC(chain[0]));
            signer.SetFieldName(fieldname);

            /* ExternalBlankSignatureContainer constructor will create the PdfDictionary for the signature
             * information and will insert the /Filter and /SubFilter values into this dictionary.
             * It will leave just a blank placeholder for the signature that is to be inserted later.
             */
            MyExternalSignatureContainer external = new MyExternalSignatureContainer();

            // Sign the document using an external container
            // 8192 is the size of the empty signature placeholder.
            signer.SignExternalContainer(external, 8192);
            byte[] hash = external.Data;
            this.hashBeforeAuthAtr = hash;
            // If Doesnot work , return the above hash and try again later.



            //PdfPKCS7 signature = new PdfPKCS7(null, chain, "SHA265", false);
            IX509Certificate[] certificateWrappers = new IX509Certificate[chain.Length];
            for (int i = 0; i < certificateWrappers.Length; ++i)
            {
                certificateWrappers[i] = new X509CertificateBC(chain[i]);
            }
            iText.Signatures.PdfPKCS7 signature = new iText.Signatures.PdfPKCS7(null, certificateWrappers, "SHA256", false);


            byte[] authAttributes = signature.GetAuthenticatedAttributeBytes(hash, PdfSigner.CryptoStandard.CMS,
                        null, null);
            return authAttributes;




        }



        // Backend Module
        [HttpGet(Name = "preparePDF")]
        public static void embedSignaturePdf(string tempFile, string targetFile, X509Certificate[] chain, byte[] hash, byte[] signedHash)
        {
            using (PdfReader reader = new PdfReader(tempFile))
            {
                using (FileStream outStream = System.IO.File.OpenWrite(targetFile))
                {
                    var signedContainer = new SignedSignatureContainer(hash, signedHash, chain);
                    PdfSigner signer = new PdfSigner(reader, outStream, new StampingProperties());
                    PdfSigner.SignDeferred(signer.GetDocument(), "field", outStream, signedContainer);
                }
            }
        }


    }


        class MyExternalSignatureContainer : IExternalSignatureContainer
        {
            public byte[] Data;
        public void ModifySigningDictionary(PdfDictionary signDic)
        {
            signDic.Put(PdfName.Filter, PdfName.Adobe_PPKLite);
            signDic.Put(PdfName.SubFilter, PdfName.Adbe_pkcs7_detached);
        }

        public byte[] getData()
            {
                return this.Data;
            }

            public byte[] Sign(Stream inputStream)
            {

                this.Data = DigestAlgorithms.Digest(inputStream, DigestAlgorithms.SHA256);
                return new byte[0];

            }
        }

        public class SignedSignatureContainer : IExternalSignatureContainer
        {
            public byte[] Hash { get; set; }
            public byte[] SignedHash { get; set; }
            public X509Certificate[] CertChains { get; set; }

            public SignedSignatureContainer(byte[] hash, byte[] signedHash, X509Certificate[] certCertChains)
            {
                this.Hash = hash;
                this.SignedHash = signedHash;
                this.CertChains = certCertChains;
            }

            public byte[] Sign(Stream data)
            {
                IX509Certificate[] certificateWrappers = new IX509Certificate[CertChains.Length];
                for (int i = 0; i < certificateWrappers.Length; ++i)
                {
                    certificateWrappers[i] = new X509CertificateBC(CertChains[i]);
                }
                iText.Signatures.PdfPKCS7 sgn = new iText.Signatures.PdfPKCS7(null, certificateWrappers, "SHA256", false);

                sgn.SetExternalSignatureValue(SignedHash, null, "RSA");
                //sgn.SetExternalDigest(this.SignedHash, null, "RSA");

                ITSAClient tsaClient = new iText.Signatures.TSAClientBouncyCastle("http://tsa.mcsd.com.eg/mcdrca2022/tsa");
                return sgn.GetEncodedPKCS7(Hash, PdfSigner.CryptoStandard.CMS, null,
                            null, null);
                //return sgn.GetEncodedPKCS7(this.Hash, null, null, null, iTextSharp.text.pdf.security.CryptoStandard.CMS);
            }

            public void ModifySigningDictionary(PdfDictionary signDic)
            {
                signDic.Put(PdfName.Filter, PdfName.Adobe_PPKLite);
                signDic.Put(PdfName.SubFilter, PdfName.Adbe_pkcs7_detached);
            }
        }
    }


